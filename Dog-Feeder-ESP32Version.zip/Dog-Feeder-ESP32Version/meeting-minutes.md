# Meeting Minutes - Dog Feeder Team 

>First record starts at 19.12.2022

Tepmlate: ## dd.mm.yy - topics was talked:
- General:

    
    <br>
- Point raised:

    1.
    2.
    3.
    <br>
- AR:

    - [ ] Ar 1
    - [ ] Ar 2
    - [ ] Ar 3

Add Below the newst meeting minutes.
___
## 18.01.23 - topics was talked:
- General:
    <br>
- Point raised:

    1. Done integrated  Gil's code with our Blynk code.
    2. ESP32 was successfully converted to an AP and then to a station, now the wifi can be set for the first time using html page.
    <br>
- AR:
    - [X] The old code should be integrated with the Gil code.    

______
## 04.01.23 - topics was talked:
- General:
    <br>
- Point raised:

    1. Consider adding IR control to the feeding system.
    2. Consider changing the LEDs and buttons configuration.
    3. ESP32 was successfully converted to an AP and then to a station using Gil code.
    <br>
- AR:
    - [X] The old code should be integrated with the Gil code.
    - [ ] Consider other concepts for the 3D module base.
    

___
## 26.12.22 - topics was talked:
- General:

    <br>
- Point raised:

    1. Talked with Gil to understand how to imploment the AP.
    2. Nadan added drills for the leds and the bts.
    3.
    <br>
- AR:
    - [ ] Give real scale to the 3d modle. 
    - [X] Test Gill [Example](https://github.com/giltal/ESP32_Course/blob/a52594c3e780bc992efb3def38f33001c21793ff/CodeExamples/WiFi/ESP32_WiFi_Lab_AP.ino) for AP
    

___
## 19.12.22 - Nadan Joined to the team, 3D moudle talks:
- General:

    An overview of the project was presented at the startup meeting, from the inspiration for the facility to the current assembly. An engineering requirements and constraints display was added, helping to improve the existing 3D model in real time.

<br>

- Point rasied:

    The main parts that affect the design of the model
  
    1. Location of drills for 3 buttons
    2. Location of drills for 3 LEDs
    3. Compartment for battery
    4. Compartment for ESP32 + servo motor + matrix(wires)
    
    <br>

    The main engineering requirements that affect the design of the model:

    1. Stability (NOVAPROOF)
    2. Adaptation to existing parts (off-the-shelf products)
    3. Adjustment for fixing to the wall/floor
    4. Easy to carry
    5. Easy to maintain (compartments at the back)
    6. Easy to assemble
<br>

- AR:

    - [ ] Body printing options
    - [x] The locations of the LEDs + buttons + cells/slots
    - [ ] Option to disassemble the model into parts (easy + cheap printing)

 ___
 
